"""Integration tests for conversation/api.py against a real Postgres
instance — matches acceptance criteria in V1_M1_IMPLEMENTATION_PLAN.md §8.
"""
import pytest
from unittest.mock import AsyncMock, patch

from conversation.api import _claims_unbacked_action, _matches_fast_path_greeting, handle
from goals.api import create_goal
from infra.storage import connection
from mission.api import set_mission
from contracts.enums import GoalType

pytestmark = pytest.mark.usefixtures("clean_db")


# --- capability-claim guard (real bug: "I've noted the word 'coco'") --

@pytest.mark.parametrize("text,expected", [
    ("I've noted the word \"coco\" for the moment.", True),  # the actual reported bug
    ("I'll remind you about that tomorrow.", True),
    ("I've saved that to your profile.", True),
    ("Got it, I'll keep track of that for you.", True),
    ("Not much, just checking the weather.", False),
    ("I don't have access to your name at the moment.", False),
    ("Sure, I can help with that once it's built.", False),
])
def test_claims_unbacked_action_detector(text, expected):
    assert _claims_unbacked_action(text) == expected


async def test_conversational_reply_claiming_memory_gets_replaced_with_honesty():
    # Direct regression test for the reported bug: LLM claims to have
    # remembered something; the conversational path has zero persistence,
    # so this must never reach the user as-is.
    await set_mission(title="Grow", statement="Statement.")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value={"needs_reasoning": False})), \
         patch("conversation.api.complete", new=AsyncMock(return_value="I've noted the word 'coco' for the moment.")):
        outcome = await handle("remember this word = 'coco'")
    assert outcome.routed_to == "conversation"
    assert "noted the word" not in outcome.response_text.lower()
    assert "can't actually save" in outcome.response_text.lower()


# --- fast-path greeting matcher (pure function, no DB/LLM needed) -----

@pytest.mark.parametrize("text,expected", [
    ("hi", True), ("hello", True), ("hey", True), ("yo", True),
    ("good morning", True), ("goodmorning", True), ("good night", True),
    ("thanks", True), ("thank you", True), ("bye", True), ("hi jarvis", True),
    ("yo whatup sleeping ?", False),
    ("what should i work on today?", False),
    ("12345", False),
    ("night owl", False),
])
def test_fast_path_greeting_matcher(text, expected):
    assert _matches_fast_path_greeting(text) == expected


# --- acceptance table cases, against a real DB ------------------------

async def test_no_mission_gives_onboarding_not_a_raw_exception():
    # bug.md BUG-001: this used to be an unhandled NoActiveMissionError.
    outcome = await handle("hello jarvis")
    assert outcome.routed_to == "conversation"
    assert "mission set" in outcome.response_text.lower()


async def test_no_mission_onboarding_is_archived():
    await handle("hello jarvis")
    async with connection() as conn:
        row = await conn.fetchrow("SELECT * FROM conversation_turn WHERE user_text = 'hello jarvis';")
    assert row is not None
    assert row["routed_to"] == "conversation"


async def test_greeting_never_reaches_reasoning():
    await set_mission(title="Grow", statement="Statement.")
    with patch("conversation.api.run_request", new=AsyncMock()) as mock_run:
        outcome = await handle("yo")
    assert outcome.routed_to == "conversation"
    mock_run.assert_not_called()


async def test_planning_question_still_routes_to_reasoning():
    # Regression guard: M1 must not change existing Planning/Reflection
    # behavior for genuine requests.
    await set_mission(title="Grow", statement="Statement.")
    await create_goal(type=GoalType.PROJECT, title="Build jarvis v1")
    outcome = await handle("what should i work on today?")
    assert outcome.routed_to == "reasoning"
    assert outcome.workflow is not None
    assert outcome.workflow.intent == "Planning"


async def test_routing_llm_failure_defaults_to_reasoning_not_conversation():
    # §3: safer default on failure — an ungrounded conversational answer
    # risks asserting something about real goals; unclear input should
    # fall into the rigorous path, not out of it.
    await set_mission(title="Grow", statement="Statement.")
    await create_goal(type=GoalType.PROJECT, title="Build jarvis v1")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value=None)):
        outcome = await handle("12345")
    assert outcome.routed_to == "reasoning"


async def test_ambiguous_input_routed_conversational_by_llm_does_not_reach_reasoning():
    await set_mission(title="Grow", statement="Statement.")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value={"needs_reasoning": False})), \
         patch("conversation.api.complete", new=AsyncMock(return_value="Ha, not much! What's up?")):
        outcome = await handle("why do you always talk about goals?")
    assert outcome.routed_to == "conversation"
    assert outcome.response_text == "Ha, not much! What's up?"


async def test_every_turn_archived_exactly_once_both_paths():
    await set_mission(title="Grow", statement="Statement.")
    await create_goal(type=GoalType.PROJECT, title="Build jarvis v1")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value={"needs_reasoning": True})):
        await handle("what should i work on today?")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value=None)), \
         patch("conversation.api.complete", new=AsyncMock(return_value="hey!")):
        await handle("yo")

    async with connection() as conn:
        rows = await conn.fetch("SELECT routed_to FROM conversation_turn ORDER BY created_at;")
    assert [r["routed_to"] for r in rows] == ["reasoning", "conversation"]


async def test_slash_commands_unaffected_by_mission_gate():
    # plan §4: /mission set must still work with no Mission — that's how
    # the first one gets created. conversation.handle is never invoked
    # for slash commands at all (cli.py dispatches those separately),
    # so this just confirms set_mission itself has no such gate.
    m = await set_mission(title="Grow", statement="Statement.")
    assert m.version == 1


# --- M1 session-context follow-up (2026-08-09) -------------------------

async def test_recent_turns_get_fed_into_the_conversational_prompt():
    import conversation.api as conv_api
    await set_mission(title="Grow", statement="Statement.")

    captured_prompt = {}

    async def fake_complete(system, prompt, task_type, max_tokens):
        captured_prompt["value"] = prompt
        return "Sure thing, Yochan."

    with patch("conversation.api.complete_json", new=AsyncMock(return_value={"needs_reasoning": False})), \
         patch("conversation.api.complete", new=AsyncMock(side_effect=fake_complete)):
        await handle("call me Yochan from now on")
        await handle("what did I just ask you to call me?")

    assert "call me Yochan from now on" in captured_prompt["value"]


async def test_session_boundary_is_real_not_just_claimed():
    # Confirms the actual fix for "gone after /exit": a turn tagged with
    # a DIFFERENT session_id (simulating a prior process run) must never
    # be picked up as "recent" by this session.
    import conversation.api as conv_api
    await set_mission(title="Grow", statement="Statement.")

    async with connection() as conn:
        await conn.execute(
            """
            INSERT INTO conversation_turn (id, session_id, user_text, response_text, routed_to, created_at)
            VALUES (gen_random_uuid(), gen_random_uuid(), 'from a previous run', 'old reply', 'conversation', now());
            """
        )

    recent = await conv_api._recent_turns()
    assert all(t.user_text != "from a previous run" for t in recent)


async def test_first_message_this_session_has_empty_recent_context():
    import conversation.api as conv_api
    assert await conv_api._recent_turns() == []


# --- Fabricated-UI guard (found in dogfooding, 2026-08-10) ------------

@pytest.mark.parametrize("text,expected", [
    ("it's all listed for you under the Mission tab.", True),  # actual reported bug
    ("check the settings page for that.", True),
    ("click the dashboard button.", True),
    ("Monkey D. Luffy is a great character.", False),
    ("I don't know much about One Piece.", False),
    ("What do you think makes Luffy great?", False),
])
def test_mentions_fabricated_ui_detector(text, expected):
    from conversation.api import _mentions_fabricated_ui
    assert _mentions_fabricated_ui(text) == expected


async def test_conversational_reply_inventing_a_ui_gets_replaced_with_honesty():
    await set_mission(title="Grow", statement="Statement.")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value={"needs_reasoning": False})), \
         patch("conversation.api.complete", new=AsyncMock(
             return_value="It's all listed for you under the Mission tab."
         )):
        outcome = await handle("what are your capabilities?")
    assert outcome.routed_to == "conversation"
    assert "mission tab" not in outcome.response_text.lower()
    assert "terminal-only" in outcome.response_text.lower()


# --- Prompt-leakage guard (found in dogfooding, 2026-08-10) -----------

@pytest.mark.parametrize("text,expected", [
    ("Mission: I wanna be ironman\n\nLet's talk about that.", True),  # actual reported bug
    ("Capabilities: reading files, calendar events", True),
    ("User: what should i do next?", True),
    ("Since your mission is to be Iron Man, let's talk about that.", False),
    ("Sorry to hear about that, want to talk?", False),
])
def test_leaks_prompt_structure_detector(text, expected):
    from conversation.api import _leaks_prompt_structure
    assert _leaks_prompt_structure(text) == expected


async def test_conversational_reply_leaking_prompt_labels_gets_replaced():
    await set_mission(title="I wanna be ironman", statement="Statement.")
    with patch("conversation.api.complete_json", new=AsyncMock(return_value={"needs_reasoning": False})), \
         patch("conversation.api.complete", new=AsyncMock(
             return_value="Mission: I wanna be ironman\n\nLet's talk about becoming Iron Man."
         )):
        outcome = await handle("she rejected me, there's nothing left to explore")
    assert outcome.routed_to == "conversation"
    assert not outcome.response_text.lower().startswith("mission:")
    assert "garbled" in outcome.response_text.lower()
