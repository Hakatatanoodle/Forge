"""Unit tests for infra/llm_router.py — routing, retry, fallback, JSON
parsing, all against mocked provider calls (real API verification is
local-testing-required, see ARCHITECTURE_ISSUES.md)."""
import pytest
from unittest.mock import AsyncMock, patch

from infra.llm_router import LLMUnavailableError, complete, complete_json


async def test_no_keys_configured_raises_after_trying_primary_and_fallback(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    with pytest.raises(LLMUnavailableError):
        await complete("hi", task_type="conversation")


async def test_primary_success_no_fallback_needed(monkeypatch):
    # openrouter -> primary (2026-08-11: proven most reliable this
    # session, and free/gpt-oss-20b needs no paid credits — see
    # infra/llm_router.py's _TASK_PROVIDER).
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(return_value="hello")) as mock_or, \
         patch("infra.llm_router._call_groq", new=AsyncMock()) as mock_groq:
        result = await complete("hi", task_type="conversation")
        assert result == "hello"
        mock_or.assert_called_once()
        mock_groq.assert_not_called()


async def test_complex_task_routes_to_openrouter(monkeypatch):
    # complex -> openrouter (2026-08-11, superseding yesterday's
    # complex->groq restoration — openrouter proved most reliable this
    # entire session, see infra/llm_router.py's _TASK_PROVIDER).
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(return_value="deep thoughts")) as mock_or:
        result = await complete("think hard", task_type="complex")
        assert result == "deep thoughts"
        mock_or.assert_called_once()


async def test_primary_failure_falls_back_to_groq(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    monkeypatch.setenv("GROQ_API_KEY", "fake-key")
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(side_effect=RuntimeError("openrouter down"))), \
         patch("infra.llm_router._call_groq", new=AsyncMock(return_value="fallback response")) as mock_groq:
        result = await complete("hi", task_type="conversation")
        assert result == "fallback response"
        mock_groq.assert_called_once()


async def test_both_primary_and_fallback_fail_raises(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    monkeypatch.setenv("GROQ_API_KEY", "fake-key")
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(side_effect=RuntimeError("openrouter down"))), \
         patch("infra.llm_router._call_groq", new=AsyncMock(side_effect=RuntimeError("groq down"))):
        with pytest.raises(LLMUnavailableError):
            await complete("hi", task_type="conversation")


async def test_complete_json_parses_valid_json(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(return_value='{"summary": "ok"}')):
        result = await complete_json(system="s", prompt="p")
        assert result == {"summary": "ok"}


async def test_complete_json_strips_markdown_fences(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    fenced = '```json\n{"summary": "ok"}\n```'
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(return_value=fenced)):
        result = await complete_json(system="s", prompt="p")
        assert result == {"summary": "ok"}


async def test_complete_json_extracts_object_from_surrounding_prose(monkeypatch):
    # Real case from dogfooding (2026-08-07): Gemini answered with
    # reasoning/bullets wrapped around the JSON instead of a clean
    # ```json fence, e.g. '...analysis...\n{"summary": "ok"}\nmore text'.
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    noisy = 'Sure, here is my analysis:\n* High relevance\n{"summary": "ok"}\nHope that helps!'
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(return_value=noisy)):
        result = await complete_json(system="s", prompt="p")
        assert result == {"summary": "ok"}


async def test_complete_json_returns_none_on_invalid_json(monkeypatch):
    monkeypatch.setenv("OPENROUTER_API_KEY", "fake-key")
    with patch("infra.llm_router._call_openrouter", new=AsyncMock(return_value="not json at all")):
        result = await complete_json(system="s", prompt="p")
        assert result is None


async def test_complete_json_returns_none_never_raises_when_unavailable(monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    result = await complete_json(system="s", prompt="p")
    assert result is None
