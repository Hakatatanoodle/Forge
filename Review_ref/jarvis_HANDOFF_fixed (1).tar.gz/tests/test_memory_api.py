"""Integration tests for memory/api.py against a real Postgres instance."""
import pytest

from contracts.enums import Importance, MemoryStatus, MemoryType
from memory.api import (
    InvalidMemoryTransitionError,
    MemoryNotFoundError,
    archive_memory,
    create_memory,
    forget_memory,
    get_memory_history,
    remember_fact,
    set_status,
    update_memory,
)

pytestmark = pytest.mark.usefixtures("clean_db")


async def test_create_memory_basic():
    m = await create_memory(
        type=MemoryType.PREFERENCE, title="Preferred IDE", value="VS Code",
        source_ids=["conversation-1"],
    )
    assert m.status == MemoryStatus.ACTIVE
    assert m.confidence == 1.0
    assert m.version == 1


async def test_update_bumps_version_and_records_history():
    m = await create_memory(
        type=MemoryType.FACT, title="Original", value="v1", source_ids=["src-1"],
    )
    m = await update_memory(m.id, reason="corrected", value="v2")
    assert m.version == 2
    assert m.value == "v2"

    history = await get_memory_history(m.id)
    assert len(history) == 1
    assert history[0]["snapshot"]["value"] == "v1"
    assert history[0]["reason"] == "corrected"


async def test_archive_then_reactivate():
    m = await create_memory(type=MemoryType.FACT, title="T", value="V", source_ids=["s"])
    m = await archive_memory(m.id, reason="no longer relevant")
    assert m.status == MemoryStatus.ARCHIVED

    m = await set_status(m.id, MemoryStatus.ACTIVE, reason="relevant again")
    assert m.status == MemoryStatus.ACTIVE


async def test_forgotten_is_terminal():
    m = await create_memory(type=MemoryType.FACT, title="T", value="V", source_ids=["s"])
    m = await forget_memory(m.id, reason="user said forget this")
    assert m.status == MemoryStatus.FORGOTTEN

    with pytest.raises(InvalidMemoryTransitionError):
        await set_status(m.id, MemoryStatus.ACTIVE, reason="should not be allowed")


async def test_operations_on_nonexistent_memory_raise():
    with pytest.raises(MemoryNotFoundError):
        await archive_memory("00000000-0000-0000-0000-000000000000", reason="x")


async def test_remember_fact_creates_new_when_no_existing_match():
    m = await remember_fact(
        type=MemoryType.FACT, title="Long-term goal: Build Jarvis",
        value="Build Jarvis", source_ids=["goal-1"],
    )
    assert m.version == 1


async def test_remember_fact_merges_into_existing_active_memory():
    first = await remember_fact(
        type=MemoryType.FACT, title="Long-term goal: Build Jarvis",
        value="Build Jarvis", source_ids=["goal-1"],
    )
    second = await remember_fact(
        type=MemoryType.FACT, title="Long-term goal: Build Jarvis v2",
        value="Build Jarvis, revised scope", source_ids=["goal-1"],
    )
    # same underlying id, merged not duplicated (§6.3: "Duplicate memories
    # should merge rather than multiply")
    assert second.id == first.id
    assert second.version == 2
    assert second.title == "Long-term goal: Build Jarvis v2"

    all_active = [m for m in [second]]  # sanity: only one row should exist
    from memory.api import list_memories
    active_memories = await list_memories(status=MemoryStatus.ACTIVE)
    assert len(active_memories) == 1


async def test_remember_fact_is_a_no_op_when_nothing_changed():
    first = await remember_fact(
        type=MemoryType.FACT, title="T", value="V", source_ids=["goal-1"],
    )
    second = await remember_fact(
        type=MemoryType.FACT, title="T", value="V", source_ids=["goal-1"],
    )
    assert second.version == first.version == 1  # no spurious version bump
