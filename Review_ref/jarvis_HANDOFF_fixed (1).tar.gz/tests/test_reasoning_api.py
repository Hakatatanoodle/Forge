"""Integration tests for reasoning/api.py — M3's Reasoning Engine.
Verifies the pipeline actually runs end-to-end against real Goals/Memory,
and that the "simplest correct" choices (deterministic reasoning, no
caching, flat budget) behave sensibly, not that they're sophisticated."""
import pytest
from unittest.mock import AsyncMock, patch

from contracts.enums import GoalStatus, GoalType, Priority
from goals.api import create_goal, set_status
from mission.api import set_mission
from reasoning.api import (
    NoActiveMissionError,
    UnknownIntentError,
    _asserts_unsupported_relationship,
    _asserts_wrong_mission,
    get_decision,
    list_decisions,
    reason,
)

pytestmark = pytest.mark.usefixtures("clean_db")


async def test_reason_requires_active_mission():
    with pytest.raises(NoActiveMissionError):
        await reason(intent="Planning", objective="What should I work on?")


async def test_reason_rejects_unknown_intent():
    await set_mission(title="Grow", statement="Statement.")
    with pytest.raises(UnknownIntentError):
        await reason(intent="Programming", objective="anything")


async def test_planning_with_no_goals_is_honest_about_it():
    await set_mission(title="Grow", statement="Statement.")
    d = await reason(intent="Planning", objective="What should I work on today?")
    assert "No active or draft goals" in d.summary
    assert d.requires_plan is False
    assert d.goal_ids == []


async def test_planning_surfaces_the_highest_relevance_active_goal():
    await set_mission(title="Grow", statement="Statement.")
    low = await create_goal(type=GoalType.TASK, title="Low priority task", priority=Priority.LOW)
    high = await create_goal(type=GoalType.LIFE_GOAL, title="Financial independence", priority=Priority.CRITICAL)
    await set_status(low.id, GoalStatus.ACTIVE, reason="starting")
    await set_status(high.id, GoalStatus.ACTIVE, reason="starting")

    d = await reason(intent="Planning", objective="What should I work on today?")
    assert d.selected_option == "Financial independence"
    assert d.requires_plan is True
    assert high.id in d.goal_ids


async def test_decision_is_persisted_and_retrievable():
    await set_mission(title="Grow", statement="Statement.")
    d = await reason(intent="Planning", objective="What should I work on today?")

    fetched = await get_decision(d.id)
    assert fetched is not None
    assert fetched.id == d.id
    assert fetched.summary == d.summary


async def test_list_decisions_filters_by_intent():
    await set_mission(title="Grow", statement="Statement.")
    await reason(intent="Planning", objective="Plan objective")
    await reason(intent="Reflection", objective="Reflect objective")

    planning_only = await list_decisions(intent="Planning")
    assert len(planning_only) == 1
    assert planning_only[0].objective == "Plan objective"

    all_decisions = await list_decisions()
    assert len(all_decisions) == 2


async def test_reflection_summarizes_completed_and_active_goals():
    await set_mission(title="Grow", statement="Statement.")
    g = await create_goal(type=GoalType.PROJECT, title="Build Jarvis")
    await set_status(g.id, GoalStatus.ACTIVE, reason="starting")
    await set_status(g.id, GoalStatus.COMPLETED, reason="done")

    d = await reason(intent="Reflection", objective="How did this go?")
    assert "1 goal(s) completed" in d.summary
    assert d.requires_plan is False


async def test_decision_confidence_and_evidence_are_populated():
    # DE-08: every recommendation must be explainable — confidence isn't
    # a magic number and context_item_ids trace back to real evidence.
    await set_mission(title="Grow", statement="Statement.")
    g = await create_goal(type=GoalType.LIFE_GOAL, title="Financial independence")
    await set_status(g.id, GoalStatus.ACTIVE, reason="starting")

    d = await reason(intent="Planning", objective="What should I work on today?")
    assert 0.0 <= d.confidence <= 1.0
    assert len(d.context_item_ids) > 0
    assert len(d.reasoning) > 0


# --- BUG-M6-01: unsupported relationship inference --------------------
# Two independent goals (no parent_goal_id, no dependencies) must never
# be described as related, connected, or dependent on each other — not
# even by the LLM enhancement step. Evidence-first (PROJECT.md).

def _fake_goal_context_item(goal, reasoning: str):
    from contracts.context_item import ContextItem
    from contracts.enums import ContextSourceType

    return ContextItem(
        source_type=ContextSourceType.GOAL,
        source_id=goal.id,
        payload=goal.model_dump(mode="json"),
        relevance_score=0.5,
        confidence=1.0,
        freshness=1.0,
        reasoning=reasoning,
    )


def test_guard_rejects_relational_language_between_unrelated_goals():
    goal_a = type("G", (), {"id": "a", "model_dump": lambda self, mode: {
        "id": "a", "title": "Build Jarvis V1", "status": "Draft",
        "parent_goal_id": None, "dependencies": [],
    }})()
    goal_b = type("G", (), {"id": "b", "model_dump": lambda self, mode: {
        "id": "b", "title": "Financial Independence", "status": "Draft",
        "parent_goal_id": None, "dependencies": [],
    }})()
    items = [
        _fake_goal_context_item(goal_a, "Project 'Build Jarvis V1' is Draft."),
        _fake_goal_context_item(goal_b, "LifeGoal 'Financial Independence' is Draft."),
    ]
    hallucinated = (
        "Since Project 'Build Jarvis V1' is related to Financial Independence, "
        "work on both today."
    )
    assert _asserts_unsupported_relationship(hallucinated, items) is True


def test_guard_allows_relational_language_for_a_real_dependency():
    goal_a = type("G", (), {"id": "a", "model_dump": lambda self, mode: {
        "id": "a", "title": "Build Jarvis V1", "status": "Draft",
        "parent_goal_id": None, "dependencies": ["b"],
    }})()
    goal_b = type("G", (), {"id": "b", "model_dump": lambda self, mode: {
        "id": "b", "title": "Financial Independence", "status": "Draft",
        "parent_goal_id": None, "dependencies": [],
    }})()
    items = [
        _fake_goal_context_item(goal_a, "Project 'Build Jarvis V1' is Draft."),
        _fake_goal_context_item(goal_b, "LifeGoal 'Financial Independence' is Draft."),
    ]
    text = "'Build Jarvis V1' depends on Financial Independence, so start there."
    assert _asserts_unsupported_relationship(text, items) is False


def test_guard_ignores_text_with_no_relational_phrase():
    goal_a = type("G", (), {"id": "a", "model_dump": lambda self, mode: {
        "id": "a", "title": "Build Jarvis V1", "status": "Draft",
        "parent_goal_id": None, "dependencies": [],
    }})()
    items = [_fake_goal_context_item(goal_a, "Project 'Build Jarvis V1' is Draft.")]
    assert _asserts_unsupported_relationship("Focus on Build Jarvis V1 today.", items) is False


async def test_reason_falls_back_to_template_when_llm_invents_a_relationship():
    # Reproduces BUG-M6-01 end-to-end: two independent Draft goals, LLM
    # mocked to return exactly the hallucinated text from the bug report.
    await set_mission(title="Grow", statement="Statement.")
    await create_goal(type=GoalType.PROJECT, title="Build Jarvis V1")
    await create_goal(type=GoalType.LIFE_GOAL, title="Financial Independence")

    hallucinated = {
        "summary": "Since Project 'Build Jarvis V1' is related to Financial Independence, "
                    "work on both today.",
        "reasoning": "Build Jarvis V1 is connected to Financial Independence.",
    }
    with patch("reasoning.api.complete_json", new=AsyncMock(return_value=hallucinated)):
        d = await reason(intent="Planning", objective="What should I work on today?")

    assert "related" not in d.summary.lower()
    assert "connected" not in d.reasoning.lower()


# --- Mission/Goal conflation guard (found in dogfooding, 2026-08-10) --

def _fake_goal_item(title):
    from contracts.context_item import ContextItem
    from contracts.enums import ContextSourceType

    return ContextItem(
        source_type=ContextSourceType.GOAL, source_id="g1",
        payload={"title": title, "status": "Active"},
        relevance_score=0.5, confidence=1.0, freshness=1.0, reasoning="",
    )


def test_guard_rejects_goal_relabeled_as_mission():
    mission = type("M", (), {"title": "I wanna be Ironman"})()
    items = [_fake_goal_item("Build jarvis v1")]
    bad = "Your active mission is to Build jarvis v1."  # the actual reported bug
    assert _asserts_wrong_mission(bad, mission, items) is True


def test_guard_allows_correct_mission_and_goal_mentioned_together():
    mission = type("M", (), {"title": "I wanna be Ironman"})()
    items = [_fake_goal_item("Build jarvis v1")]
    good = "Focus on 'Build jarvis v1' — it supports your mission 'I wanna be Ironman'."
    assert _asserts_wrong_mission(good, mission, items) is False


def test_guard_ignores_generic_mission_mention_with_no_conflation():
    mission = type("M", (), {"title": "I wanna be Ironman"})()
    items = [_fake_goal_item("Build jarvis v1")]
    assert _asserts_wrong_mission("Your mission is going well!", mission, items) is False


async def test_reason_falls_back_to_template_when_llm_conflates_goal_with_mission():
    # Real bug, real query shape: user asks about "missions," Mission
    # title was never in the LLM's evidence before this fix, so it
    # relabeled the top Goal as "the mission" instead — confidently wrong.
    await set_mission(title="I wanna be Ironman", statement="Statement.")
    await create_goal(type=GoalType.PROJECT, title="Build jarvis v1")

    conflated = {
        "summary": "Your active mission is to Build jarvis v1.",
        "reasoning": "The goal Build jarvis v1 is currently Active.",
    }
    with patch("reasoning.api.complete_json", new=AsyncMock(return_value=conflated)):
        d = await reason(intent="Planning", objective="what missions do i have?")

    # The template is allowed to mention the goal — that's normal. What
    # must never survive is the conflated claim itself.
    assert d.summary != "Your active mission is to Build jarvis v1."
    assert "mission" not in d.summary.lower()
