# Architecture Issues Log

Format and rules per §10 of the Jarvis V0 Implementation Prompt. Every entry
here is real — hit during the actual M0 build, not hypothetical. I keep
building on my best-faith interpretation after logging; I don't block
waiting for a response.

---

## [2026-08-01] Action.permission_check_id cannot be unconditionally required

**Contract/section:** §6.7 Action

**What broke:** §6.7's JSON shape lists `permission_check_id` as a plain
required `id` field, added specifically to close the audit-trail gap (every
Action must be traceable to the PermissionCheckResult that authorized it).
Taken completely literally, this makes it impossible to construct an Action
in its own first lifecycle state, `Pending` — by definition, the Permission
Check (§2's pipeline step, which runs *after* Planner produces Actions)
hasn't happened yet at that point. §6.9 itself implies this ordering:
"the Action Engine may not transition the Action past `Ready`" without a
resolved confirmation, which only makes sense if `Ready` (not `Pending`) is
the state that requires an existing PermissionCheckResult.

**What I did instead:** Made `permission_check_id` `Optional[str] = None` at
the model level, but added a `model_validator` that raises unless it's set
whenever `status != Pending`. This preserves both things the contract cares
about: a legitimate pre-authorization `Pending` state exists, and nothing
can reach `Ready`/`Running`/`Completed`/`Failed` without a traceable
authorization. See `contracts/action.py`.

**Needs architect decision:** no — this reads as an oversight in how the
JSON shape was written down, not a real design disagreement. Flagging in
case there's a reason `Pending` Actions were meant to already carry a
permission_check_id (e.g. if Permission Check was meant to run before
Planner in some flow I'm not aware of).

---

## [2026-08-01] PermissionCheckResult.computed_risk cannot be fully
enforced until the risk calculator exists (M4)

**Contract/section:** §6.9 PermissionCheckResult

**What broke:** §6.9's invariant states `computed_risk` is "always derived
from `baseline_risk + risk_factors` — never set directly by any caller."
The mechanism that performs that derivation is the dynamic risk formula
(decision #2, §4: `baseline_risk + parameter_risk + impact + reversibility
+ scope`), which §7's repo structure explicitly scopes to
`permission/risk_calculator.py` — an M4 deliverable. M0 only builds
`contracts/`.

**What I did instead:** The M0 contract enforces everything checkable at
the schema level today (valid `RiskLevel` enum values on both fields,
`confirmation_status` consistency with `permission_status`), and documents
in the module docstring that the "never set directly" half of the
invariant isn't mechanically enforceable until M4, when the risk
calculator's factory function becomes the only legitimate constructor for
this record. Nothing in M0-M3 constructs a real `PermissionCheckResult`
against live data, so this doesn't block anything before M4.

**Needs architect decision:** no — this is purely a sequencing fact of
building contracts before the subsystem that populates them.

**RESOLVED in M4:** `permission/risk_calculator.py`'s `compute_risk()` is
now the only code path that produces a `computed_risk` value;
`permission/api.py` never accepts one as a caller-supplied argument.

---

## [2026-08-01] LearningProposal (§6.11) full shape was reconstructed, not given

**Contract/section:** §6.11 LearningProposal

**What broke:** §6.11 explicitly says "Full shape available on request from
the architect if not reconstructable from this summary" — meaning the
implementation prompt itself flags this contract as a summary, not a final
schema.

**What I did instead:** Reconstructed a full field set from the summary
(`category`, `evidence_ids` min 2, `confidence`, `status`,
`resulting_memory_id`) plus fields implied elsewhere in the source
documents: `learning.md` LE-05 ("Log includes: Evidence, Confidence, Date
learned, Date updated, Current status") and LE-06 (rejection lowers
confidence and records the correction, which implied a `rejection_reason`
field). Added `title`, `description`, `proposed_value`, `created_at`,
`updated_at`, `resolved_at` to make the shape usable. See
`contracts/learning_proposal.py`.

**Needs architect decision:** yes — this contract isn't used until M8
(§5.2, Learning Engine), so there's no urgency, but it should get an
explicit look before M8 starts rather than being taken as final just
because it's sitting in `contracts/`.

---

## [2026-08-02] Goal has no specified versioning mechanism

**Contract/section:** §6.2 Goal

**What broke:** §6.2 gives Goal a plain `version: 1` integer with no
`previous_version_id` or snapshot mechanism — unlike Mission (§6.1), which
explicitly specifies new-id-per-version with `previous_version_id`
linking them. Meanwhile the older `goals_contract.md` (RFC-002) says
"Versioned: Yes — Every meaningful change creates a new version" and
"Never overwrite. Archive previous versions. Store why they changed."
(Goals.md G-03) — both implying some real history mechanism exists, just
not which one.

**What I did instead:** Chose a stable-id approach, not Mission's
new-id-per-version approach: Goal keeps one row with an in-place `version`
counter, and every meaningful update snapshots the pre-change state into
a new `goal_history` table (append-only, `{goal_id, version, snapshot,
reason, changed_at}`) before applying the change. Reasoning: Goal ids are
referenced pervasively elsewhere in the architecture — `parent_goal_id`,
`dependencies` arrays, and (once Decision/Plan exist) `Decision.goal_ids`
— in a way Mission's id never is. Mission changes are also explicitly
"extremely rare" (§6.1); Goal changes ("every meaningful change") are
routine. Giving Goal a new id per version the way Mission does would
silently break every existing reference to it on every edit. See
`infra/migrations/0003_goal_history.sql` and `goals/api.py`'s
`_snapshot_and_update`.

As part of the same decision: §6.2 also says "Completed Goals cannot be
modified except through versioning" — since every write in `goals/api.py`
already goes through the same versioned snapshot-and-update path with no
non-versioned write path existing at all, I read this as automatically
satisfied rather than requiring a special-case block on `status ==
Completed`. Flagging in case the intent was actually "Completed Goals are
immutable, full stop" (matching Plan's flat "Completed Plans are
immutable," §6.6, which has no stated exception).

**Needs architect decision:** yes — specifically (1) whether stable-id +
history-table is the right call vs. Mission-style new-id-per-version, and
(2) whether Completed Goals should truly be blocked from any further
update, including versioned ones.

---

## [2026-08-02] Goal status lifecycle diagram is incomplete for real operation

**Contract/section:** §6.2 Goal (lifecycle diagram)

**What broke:** §6.2's lifecycle diagram shows only `Draft → Active →
Paused → Completed`, plus separate `Active → Archived` and `Active →
Cancelled` branches. Taken literally: there's no way back from `Paused`
(no resume), no way to abandon a `Draft` goal without ever activating it,
and no way to archive a `Completed` goal for cleanup — all realistic,
needed operations for a system meant to run for years.

**What I did instead:** Implemented `_ALLOWED_TRANSITIONS` in
`goals/api.py` as the documented paths plus the obvious symmetric/
terminal completions: `Draft → {Active, Archived, Cancelled}`, `Active →
{Paused, Completed, Archived, Cancelled}`, `Paused → {Active, Archived,
Cancelled}`, `Completed → {Archived}`, with `Archived`/`Cancelled` as
terminal states. Every transition not in this table is rejected with
`InvalidGoalTransitionError`.

**Needs architect decision:** no — this reads as the diagram showing the
"happy path" rather than the full state machine (the same pattern
Jarvis_Contract_Review_v1.md already flagged for RFC-015 generally: individual
contracts are consistently richer than any single linear diagram of them).
Flagging so the added transitions are visible and reviewable, not silently
assumed correct.

---

## [2026-08-02] Only 2 of 7 Constitution rule-based memory categories have a wireable trigger in V0

**Contract/section:** §5.1 (Memory, rule-based creation) / constitution.md's
"Rule-Based (Deterministic)" always-store list

**What broke:** constitution.md lists seven categories that should always
become memories with no AI judgment: long-term goals, active projects,
important people, preferences, permissions, recurring routines, core life
events. The implementation prompt's §5.1 scopes M2 to "rule-based creation
only... the deterministic triggers listed in the Constitution" but doesn't
specify *what fires* each trigger — and five of the seven categories have
no subsystem in V0 to fire from: there's no People/Contacts entity, no
explicit preference-capture surface, the Permission System isn't built
until M4, and nothing tracks routines or life events. Building placeholder
subsystems for these now would be exactly the kind of unscoped addition
§0's Prime Directive prohibits ("Build what's in scope. Don't add what
isn't, however easy it would be.").

**What I did instead:** Wired the two categories that do have a real data
source — "long-term goals" and "active projects" — directly to the Goal
system that M1 already built: `goals/api.py`'s `set_status()` calls
`memory.api.remember_fact()` whenever a `LifeGoal` or `Project` Goal
transitions to `Active`, unconditionally, no AI involved. Left
`memory.api.remember_fact()` itself generic (type + title + value +
source_ids, no Goal-specific knowledge) so the other five categories can
be wired in later — from a People/Contacts subsystem, an explicit
preference-declaration surface, the eventual Permission System (M4), etc.
— without needing to touch `memory/api.py` again.

Worth noting separately: constitution.md also describes a third memory-
creation method, **User-Controlled** ("Remember this," "Forget this," "Never
forget this") — but the implementation prompt's §5.1/§5.2/§5.3 scope split
only ever assigns milestones to Rule-Based (M2) and AI-based (M8),
never to User-Controlled. That's a real gap in the milestone plan itself,
not something I can resolve by picking an interpretation — User-Controlled
creation needs a command entry point that doesn't exist until the
Orchestrator (M6) is built, so it can't be scoped into any earlier
milestone regardless of what the plan says.

**Needs architect decision:** yes — specifically, where User-Controlled
memory creation should land in the M0-M8 milestone plan (my assumption,
stated here rather than silently acted on: it belongs at or after M6,
once there's an Orchestrator to parse commands against). The five
uncovered rule-based categories don't need a decision now, just a data
source that doesn't exist yet.

---

## [2026-08-02] M3 Reasoning Engine: no live LLM, Decision has nowhere to store intent, and the context_item_ids invariant was too strict

**Contract/section:** §6.5 Decision, §5.1 (Reasoning Engine)

**What broke, three related things found building M3:**

1. Per direct architect guidance (2026-08-02: "don't optimize retrieval
   yet, build the simplest correct reasoning pipeline first"), and
   because no `infra/llm_router.py` exists yet (arguably M6/Orchestrator's
   job per §7's repo structure, not M3's) and no LLM credential wiring
   exists in this environment, `reasoning/api.py`'s Decision generation is
   template-based Python, not a live model call. Every field a Decision
   needs (`reasoning`, `confidence`, evidence) is achievable this way for
   V0's two narrow intents.

2. §6.5's canonical Decision schema has no field to persist which
   intent/retrieval-policy produced it, even though DE-02 says intent
   classification "determines the reasoning strategy" — a fact that's
   clearly useful to keep queryable later (e.g. "show me all Planning
   decisions"). Added `intent` as a plain extra column on the `decision`
   table (not part of the Pydantic contract's shape, so callers reading
   §6.5-shaped `Decision` objects see no difference) rather than losing
   the information or fighting the schema.

3. `contracts/decision.py`'s "at least one ContextItem" validator (which
   I added myself in M0, carried forward from the older RFC-007 doc, not
   from the canonical §6.5 text) turned out to be wrong: "no active Goals
   exist yet" is a legitimate, real Decision with zero ContextItems to
   point to, and the alternative — fabricating a placeholder ContextItem
   just to satisfy the count — would violate ContextItem's own "must
   reference an existing source" principle worse than having none at all.

**What I did instead:** Relaxed the `context_item_ids` validator to allow
an empty list, and added a `reasoning`-must-be-non-empty validator in its
place — so explainability (DE-08) is still enforced, just through the
field actually meant to carry it, not a proxy count.

**Needs architect decision:** yes for (1) and (2) — whether Decision
generation should stay template-based longer than M3, or whether the
intent field should be formally added to §6.5 rather than living as an
extra DB column. No for (3) — that one was my own over-strict addition
being corrected by real usage, not a spec conflict.

---

## [2026-08-03] M6: Planner only ever compiles goals.advance actions

**Contract/section:** §5.1 Planner, §11 Definition of Done

**What broke:** §11 wants "at least three distinct real end-to-end
request types... including at least one that hits the Permission Check
confirmation path." Planner (M4) compiles a Plan into one `goals.advance`
Action per goal — that's the only capability it knows how to select, by
design (§5.1: "flat task lists... no dependency-graph solver," not a
capability-matching intelligence). `goals.advance` is Low-risk and always
auto-grants (§4's risk formula never pushes it past Medium). So the real,
Planner-driven pipeline currently cannot produce a confirmation-required
action on its own — only Reasoning->Planner->Permission->Action for
low-risk work is exercised end-to-end for real.

**What I did instead:** `orchestrator/api.py`'s sequencing logic (the
actual M6 deliverable) handles all three permission outcomes correctly;
the test proving the confirmation path (`test_m6_orchestrator.py`)
injects a `calendar.create_event` Action directly onto an Orchestrator-
created Plan to exercise that logic, rather than waiting for Planner to
produce one naturally — documented inline in the test file, not hidden.

**Needs architect decision:** yes — whether Planner should gain any
capability-selection logic beyond "one goals.advance per goal" before V0
ships, or whether this is fine for V0 and real capability variety is a
V1 concern once Planner has more capabilities and goal types to choose
from.

---

## [2026-08-04] Docker Compose and real LLM providers: local verification required

**Contract/section:** infra deliverables (Docker, LLM Router) — architect
decision 2026-08-04

**What broke:** neither is verifiable from the build sandbox — the
network allowlist has no route to Docker Hub or to Groq/Gemini/
OpenRouter's APIs (only Anthropic, GitHub, PyPI/npm, and Ubuntu's package
mirrors are reachable).

**What I did instead:** `docker-compose.yml` uses the same
`pgvector/pgvector:pg16` image and settings already proven to work
natively in this environment throughout the entire M0-M7 build — the
Postgres/pgvector layer itself has been exercised in every milestone,
just not through Docker specifically. `infra/llm_router.py`'s logic
(fixed routing, retry, fallback, JSON parsing/fence-stripping) is
covered by `tests/test_llm_router.py` against mocked provider calls —
real request/response shape from Groq/Gemini/OpenRouter has not been
confirmed. The CLI itself (`cli.py`) was smoke-tested end-to-end in this
sandbox against the real local Postgres instance with no LLM keys set,
confirming the fallback path works correctly under real conditions.

**Needs architect decision:** no — this is a sandbox capability
limitation, not a design question. Both need one local verification pass
with real Docker and real API keys before daily use starts. If any
provider's actual response shape differs from what `_call_groq`/
`_call_gemini`/`_call_openrouter` expect (e.g. a different JSON field
path), that's a small, mechanical fix localized to one function each —
not an architecture question.

## [2026-08-05] BUG-M6-01: Reasoning Engine invented an unsupported goal relationship

**Contract/section:** reasoning/api.py's LLM enhancement step (`reason()`
pipeline, M3) — evidence-first principle (PROJECT.md, RE-06/RV-04).

**What broke:** found during dogfooding. Two independent Draft goals, no
`parent_goal_id`/`dependencies` link between them. Asking "What should I
work on today?" produced a Decision claiming the goals were related and
proposed work on both. Root cause: `_template_planning_decision` joins
each goal's evidence sentence into one plain-text block
(`" ".join(top_reasons)`), and that block was handed to the LLM
enhancement step with no structural signal that the goals were
unrelated — two true, adjacent sentences left the LLM room to narrate a
connection neither the prompt nor the data actually stated.

**What I did instead:** two changes, contained entirely in
`reasoning/api.py`, no other subsystem touched:
1. `_build_structured_evidence` now serializes goal evidence as JSON with
   an explicit `relationships` field per goal (sourced only from
   `Goal.parent_goal_id`/`dependencies`), replacing the plain-text join
   for the LLM prompt. `_LLM_SYSTEM` explicitly forbids stating or
   implying a relationship not present in that field.
2. `_asserts_unsupported_relationship` is a deterministic guard run on
   every LLM enhancement result: if the output pairs relational language
   with two goal titles that have no explicit link in the data, the
   enhancement is rejected and the template output (which never invents
   relationships) is used instead. Prompting alone was judged
   insufficient — validation is the actual guarantee.

Per Engineering Principle #11: the guard's phrase list is a heuristic,
not a proven-complete filter — a hypothesis. A false rejection just
falls back to the safe template, so the cost of a miss is low; expand
`_RELATIONAL_PHRASES` if real usage surfaces a phrasing it misses.

**Needs architect decision:** no — this is a bug fix consistent with the
existing "LLM generates prose, structure stays deterministic" rule
(Principle #8), not a new invariant. Flagging here per Principle #10 so
it's visible, and because it's the first real case of an LLM enhancement
being rejected outright rather than just falling back on empty/invalid
JSON.

## [2026-08-07] Mission's new-id-per-version orphans every existing Goal on edit

**Contract/section:** interaction between §6.1 Mission (new-id-per-
version) and §6.2 Goal's `mission_id` foreign key — found in dogfooding,
not caused by any of the CLI/reasoning fixes made this session.

**What broke:** `set_mission()` gives every superseding version a brand
new `Mission.id` (this was an intentional, already-logged decision —
see the 2026-08-02 entry above, which reasoned this was *safe* for
Mission specifically because "Mission changes are explicitly extremely
rare"). But `Goal.mission_id` is a foreign key to that same id, and
both `planning_policy` and `reflection_policy` call
`list_goals(mission_id=<currently active mission's id>)`. The moment a
Mission is superseded, every existing Goal — still perfectly valid,
nothing wrong with it — becomes invisible to Planning and Reflection,
because its `mission_id` points at a now-inactive version row. Reproduced
directly: `/mission set` twice in one session (v1→v2→v3), then `what
should i work on?` → "No active or draft goals found to plan around,"
despite `/goal list` showing an Active goal the whole time.

The 2026-08-02 entry's "extremely rare" assumption is the load-bearing
piece here, and real dogfooding already contradicts it — editing the
mission statement turned out to be something a user does in normal
testing, not a once-a-year event.

**What I did instead:** nothing yet — this is a data-model question
(how Goal should reference "the Mission" across versions), not a
localized bug fix, and changing it touches a foreign key relationship
central to two other subsystems' retrieval policies. Flagging per
Principle #10 rather than picking an approach unilaterally.

**Needs architect decision:** yes. Options, roughly in order of
intrusiveness:
1. Give Mission a stable "identity" id separate from its per-version row
   id (mirrors Goal's own stable-id + history-table pattern), and point
   `Goal.mission_id` at the identity, not the version row. Most correct,
   needs a migration.
2. On supersede, backfill: `UPDATE goal SET mission_id = <new id> WHERE
   mission_id = <old id>`. Cheap, no schema change, but conceptually odd
   — Goals aren't being edited, so silently rewriting their FK on an
   unrelated Mission edit is a side effect that isn't obviously legible
   from any single subsystem's own log.
3. Change `planning_policy`/`reflection_policy` to resolve "the active
   mission's full version lineage" (all ids that share a
   `previous_version_id` chain) instead of a single exact id. No schema
   change, but pushes the coupling into two policy functions instead of
   fixing it at the data layer.

## [2026-08-07] Follow-up: same bug existed in Goal reparenting too

**Contract/section:** follow-up to the entry directly above.

**What broke:** `set_parent()`'s cross-mission guard
(`goals/api.py`) compared two goals' `mission_id` fields to reject
reparenting across missions. It only ever "worked" by accident — under
V0's single-active-mission model, `set_mission()` always supersedes the
current mission rather than creating an independent second one, so
"Mission 1" and "Mission 2" in `test_reparent_across_missions_rejected`
were actually the same mission lineage. The test only passed because of
the same per-version-id bug just fixed: two goals created before/after a
Mission edit had different `mission_id`s, which the guard misread as
"different missions."

**What I did instead:** fixed alongside the main fix, same PR. Renamed
the test to `test_reparent_survives_a_mission_edit` and asserted the
now-correct behavior (reparenting across a mere edit succeeds). Left the
guard itself in place with a note that it's currently unreachable via
any public API path in V0 — still a correct invariant, just untestable
until/unless V0 ever supports more than one concurrent Mission identity.

**Needs architect decision:** no — same fix, same reasoning as the entry
above; noting separately only because it surfaced in a different
subsystem's test suite and is worth being visible on its own.
