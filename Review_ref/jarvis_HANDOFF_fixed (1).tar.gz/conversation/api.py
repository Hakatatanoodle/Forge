"""Conversation layer (V1-M1, V1_M1_IMPLEMENTATION_PLAN.md). Restores the
`Conversation` stage named in HOW_JARVIS_THINKS.md's original flow
(User -> Conversation -> Orchestrator -> ...) but never built in V0.

Exactly two jobs, no more (plan §1):
1. Mission gate — does an active Mission exist? If not, onboarding.
2. Routing — does this need Reasoning's grounded, evidence-first
   machinery, or is it ordinary conversation?

Does NOT do intent classification (Planning vs. Reflection stays inside
orchestrator/reasoning, untouched), does NOT do natural-language CRUD
(explicitly out of scope, plan §9), and only ever touches
Goals/Mission/Memory read-only (checking Mission existence).

Every turn — both routing paths — gets one row in the flat, append-only
ConversationTurn archive (plan §5/6). Never persisted as a Decision,
never spawns a Plan on the conversational path; the reasoning path is
untouched and still does exactly what it always did.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal, Optional
from uuid import uuid4

from capabilities.registry import list_capabilities
from contracts.conversation_turn import ConversationTurn
from contracts.mission import Mission
from infra.llm_router import LLMUnavailableError, complete, complete_json
from infra.logging import get_logger
from infra.storage import connection
from mission.api import get_active_mission
from orchestrator.api import WorkflowResult, run_request

log = get_logger("conversation.api")

# One id per process — this is the actual session boundary. Generated
# once at import time, so it's stable for the life of one `python3
# cli.py` run and different on every restart. This is what makes "gone
# after /exit" a real, enforced fact rather than an assumption (see
# contracts/conversation_turn.py's docstring for the full reasoning).
_SESSION_ID = str(uuid4())
_RECENT_TURNS_LIMIT = 6

_ONBOARDING_MESSAGE = (
    "Hey — I don't have a Mission set for you yet, so I can't help you plan "
    "or reflect on anything until I know what you're working toward.\n\n"
    "Run /mission set <title> | <statement> to get started, or /help to see "
    "everything I can do."
)

# §3: small, tight, unambiguous set — anything longer or less certain
# falls through to the LLM routing check instead of guessing here.
_GREETING_WORDS = {
    "hi", "hello", "hey", "yo", "sup", "thanks", "thank", "bye", "goodbye",
    "goodmorning", "goodnight", "morning", "night",
}
_GREETING_FILLER = {"good", "you", "jarvis", "there"}
_MAX_FAST_PATH_WORDS = 3

_ROUTING_SYSTEM = (
    "Does the user's message require Jarvis's goal/mission/memory-grounded "
    "reasoning to answer, or is it ordinary conversation? Say true ONLY if "
    "the message is actually asking about the user's real goals, mission, "
    "or progress — not just because it's phrased like 'what should I do' "
    "or 'how do I'. This distinction matters: routing something to "
    "reasoning that shouldn't be there doesn't just give a bad answer, it "
    "spuriously touches the user's real goal history. Examples that need "
    "reasoning (true): 'what should I work on today', 'how am I doing on "
    "my goals', 'prioritize my tasks'. Examples that do NOT need "
    "reasoning (false), even though they're phrased as questions or "
    "requests: personal or relationship advice unrelated to goals ('I "
    "like this girl, what should I do'), questions about Jarvis itself or "
    "how to use it ('how do I access X', 'what are your capabilities'), "
    "greetings, small talk, opinions, banter. Respond ONLY with JSON: "
    '{"needs_reasoning": true} or {"needs_reasoning": false}.'
)

_CONVERSATIONAL_SYSTEM = (
    "You are Jarvis, a personal AI operating system, responding in ordinary "
    "conversation — not a planning or reflection request. Be warm, brief, "
    "and personable. You may reference the user's Mission title if it helps "
    "the reply feel grounded, but NEVER assert anything specific about the "
    "user's actual goals, memories, or progress — you don't have that "
    "evidence in front of you right now, and inventing it would be a "
    "hallucination. You will be told exactly what capabilities exist in "
    "this system and which of them you can use right now (usually none, in "
    "this reply) — NEVER claim to have saved, remembered, noted, "
    "scheduled, set, tracked, or done anything persistent, even if the "
    "user asks you to, unless you were explicitly told that capability is "
    "available to you right now. If you can't do something, say so "
    "plainly instead of pretending you did. You will also be shown recent "
    "turns from this same conversation session — you may naturally use "
    "anything the user told you earlier in this session (e.g. a name they "
    "asked you to use), but this context does not survive past this "
    "session, so don't imply it will (e.g. don't say 'I'll always "
    "remember that'). IMPORTANT: when the user asks whether you remember "
    "or know something, check the 'Recent conversation this session' "
    "section first. If it's there, state it directly and confidently — "
    "do NOT reflexively say things like 'I don't have memory of our "
    "conversation' if the answer is literally shown to you above. Only "
    "say you don't know something if it genuinely isn't in the Mission, "
    "Capabilities, or Recent conversation sections you were given. You "
    "will also be told the real interface this system has — NEVER refer "
    "to a UI element (tab, menu, button, dashboard, etc.) that isn't "
    "actually one of the listed slash commands; this is a terminal-only "
    "system with no graphical interface at all."
)
_FALLBACK_REPLY = "Hey — I'm here, just couldn't reach a language model for that reply. What can I help with?"
_CANNOT_PERSIST_REPLY = (
    "I can't actually save or remember new things yet from a conversation "
    "like this — that capability doesn't exist in the system right now. I "
    "can still help with your goals, mission, and planning — try /goal, "
    "/mission, or just ask me what to work on."
)
_NO_GUI_REPLY = (
    "Just to be accurate — there's no menu or screen for that. This is a "
    "terminal-only system right now: /mission, /goal, /memory, /status, "
    "/decision, and /help are the whole interface."
)
_MALFORMED_REPLY_FALLBACK = "Sorry, that came out a bit garbled on my end — could you say that again?"

# Layer 2 (guarantee, not just reduce — same pattern as BUG-M6-01):
# the conversational path is, by construction, side-effect-free — it
# never calls Action Engine, never persists anything beyond its own
# read-only archive row (§5/6). That's a true structural fact for M1,
# not a guess, so ANY first-person claim of having done or promising to
# do something persistent is false, regardless of the specific wording.
# Broad on purpose: a false positive just swaps in the honest fallback
# (always safe); a miss lets a real lie through (the worse direction).
_ACTION_CLAIM_VERBS = {
    "note", "noted", "save", "saved", "remember", "remembered", "record",
    "recorded", "log", "logged", "add", "added", "set", "schedule",
    "scheduled", "remind", "reminded", "track", "tracked", "store",
    "stored", "keep", "kept", "update", "updated", "jot", "jotted",
}
_ACTION_CLAIM_SUBJECTS = re.compile(r"\b(i've|i have|i'll|i will|ive|i'm going to|im going to)\b")

# Found in dogfooding, 2026-08-10: the responder told the user their
# capabilities were "listed for you under the Mission tab" — a fully
# fabricated UI surface. This system has exactly one interface: this
# terminal and its slash commands. No tabs, menus, buttons, or screens
# exist anywhere. Different failure class from the action-claim guard
# above (that catches false persistence claims; this catches false
# claims about the product itself) — same "structured grounding +
# deterministic check" shape, applied to a different hallucination.
_REAL_INTERFACE = (
    "The ONLY interface that exists is this terminal, via slash commands: "
    "/mission, /goal, /memory, /status, /decision, /help. There is no "
    "GUI, no tabs, no menus, no buttons, no dashboard, no app, no website "
    "— nothing but this terminal. NEVER refer the user to a UI element "
    "that isn't one of these slash commands."
)
_FABRICATED_UI_TERMS = {
    "tab", "tabs", "menu", "button", "dashboard", "sidebar", "dropdown",
    "checkbox", "toggle", "settings page",
}


def _mentions_fabricated_ui(reply: str) -> bool:
    lowered = reply.lower()
    return any(re.search(rf"\b{re.escape(term)}\b", lowered) for term in _FABRICATED_UI_TERMS)


# Found in dogfooding, 2026-08-10: a reply started with the literal line
# "Mission: I wanna be ironman" — the model pattern-matched the prompt's
# own "Label: value" formatting (see _conversational_reply's prompt
# construction) and echoed it back instead of just answering. This is a
# coherence/formatting failure, not a factual-grounding one — same
# category as reasoning/api.py's _looks_garbled, not the same category
# as the action-claim or fabricated-UI guards above. Checks for any line
# starting with one of the prompt's own literal field labels.
_PROMPT_LABELS = ("mission:", "capabilities:", "interface:", "recent conversation this session:", "user:")


def _leaks_prompt_structure(reply: str) -> bool:
    return any(line.strip().lower().startswith(_PROMPT_LABELS) for line in reply.splitlines())


def _capability_grounding() -> str:
    caps = list_capabilities()
    if not caps:
        return "No capabilities are registered in this system at all right now."
    names = "; ".join(f"{c.id} ({c.description})" for c in caps)
    return (
        f"Capabilities that exist in this system: {names}. None of these "
        "are available to you in this conversational reply — you are "
        "generating text only, with no ability to call any capability, "
        "save anything, or take any action right now."
    )


def _claims_unbacked_action(reply: str) -> bool:
    lowered = reply.lower()
    if not _ACTION_CLAIM_SUBJECTS.search(lowered):
        return False
    return any(re.search(rf"\b{v}\b", lowered) for v in _ACTION_CLAIM_VERBS)


# Note (2026-08-09, deliberate, not an oversight): session-context below
# means the archive genuinely does carry "coco" into the next few turns
# now, so a claim like "I've noted that" is roughly true within this
# session's recent-turns window. This guard is kept strict anyway —
# unconditionally flagging any persistence claim — rather than adding a
# second heuristic to distinguish "session-scoped" from "permanent"
# claims. Reasoning: (a) the archive's recall is bounded, unstructured,
# and not something the user can rely on the way "I'll remember that"
# implies, so staying humble about it is still the more honest framing;
# (b) a session-vs-permanent distinction is exactly the kind of fragile,
# growing heuristic surface already rejected once this session for the
# routing design. The trade-off costs nothing functionally — recent
# turns still get included either way — it just means Jarvis describes
# its own ability more conservatively than it strictly needs to.


def _row_to_turn(row) -> ConversationTurn:
    return ConversationTurn(
        id=str(row["id"]), session_id=str(row["session_id"]), user_text=row["user_text"],
        response_text=row["response_text"], routed_to=row["routed_to"], created_at=row["created_at"],
    )


async def _recent_turns(limit: int = _RECENT_TURNS_LIMIT) -> list[ConversationTurn]:
    async with connection() as conn:
        rows = await conn.fetch(
            "SELECT * FROM conversation_turn WHERE session_id = $1 ORDER BY created_at DESC LIMIT $2;",
            _SESSION_ID, limit,
        )
    return [_row_to_turn(r) for r in reversed(rows)]  # chronological order for the prompt


def _format_recent_context(turns: list[ConversationTurn]) -> str:
    if not turns:
        return "(none yet — this is the first message this session)"
    return "\n".join(f"User: {t.user_text}\nJarvis: {t.response_text}" for t in turns)


@dataclass
class ConversationOutcome:
    routed_to: Literal["conversation", "reasoning"]
    response_text: str
    workflow: Optional[WorkflowResult] = None


def _matches_fast_path_greeting(text: str) -> bool:
    cleaned = re.sub(r"[^\w\s]", "", text.lower()).strip()
    words = cleaned.split()
    if not words or len(words) > _MAX_FAST_PATH_WORDS:
        return False
    return any(w in _GREETING_WORDS for w in words) and all(
        w in _GREETING_WORDS or w in _GREETING_FILLER for w in words
    )


async def _needs_reasoning(user_text: str) -> bool:
    result = await complete_json(
        system=_ROUTING_SYSTEM, prompt=user_text, task_type="fast", max_tokens=20
    )
    if result and isinstance(result.get("needs_reasoning"), bool):
        return result["needs_reasoning"]
    # §3: safer default on failure/garbage — an under-grounded conversational
    # answer risks accidentally asserting something about the user's actual
    # goals (BUG-M6-01's failure class); routing into the rigorous path
    # costs nothing but a slightly more formal answer.
    log.info("Conversation routing LLM call unavailable/invalid — defaulting to needs_reasoning=True")
    return True


async def _conversational_reply(user_text: str, mission: Mission) -> str:
    recent = await _recent_turns()
    prompt = (
        f"Mission: {mission.title}\n"
        f"Capabilities: {_capability_grounding()}\n"
        f"Interface: {_REAL_INTERFACE}\n"
        f"Recent conversation this session:\n{_format_recent_context(recent)}\n"
        f"User: {user_text}"
    )
    try:
        reply = (await complete(
            system=_CONVERSATIONAL_SYSTEM, prompt=prompt, task_type="conversation", max_tokens=200
        )).strip()
    except LLMUnavailableError as e:
        log.info(f"Conversational reply unavailable — using fallback: {e}")
        return _FALLBACK_REPLY

    if _leaks_prompt_structure(reply):
        log.warning(
            "Conversational reply rejected — echoed the prompt's own field labels "
            "(prompt-leakage guard); using generic fallback"
        )
        return _MALFORMED_REPLY_FALLBACK
    if _claims_unbacked_action(reply):
        log.warning(
            "Conversational reply rejected — claimed an action this path cannot "
            "perform (capability-claim guard); using honest fallback"
        )
        return _CANNOT_PERSIST_REPLY
    if _mentions_fabricated_ui(reply):
        log.warning(
            "Conversational reply rejected — referenced a UI element that doesn't "
            "exist (fabricated-UI guard); using honest fallback"
        )
        return _NO_GUI_REPLY
    return reply


async def _archive(user_text: str, response_text: str, routed_to: Literal["conversation", "reasoning"]) -> None:
    turn = ConversationTurn(
        session_id=_SESSION_ID, user_text=user_text, response_text=response_text, routed_to=routed_to
    )
    async with connection() as conn:
        await conn.execute(
            """
            INSERT INTO conversation_turn (id, session_id, user_text, response_text, routed_to, created_at)
            VALUES ($1, $2, $3, $4, $5, $6);
            """,
            turn.id, turn.session_id, turn.user_text, turn.response_text, turn.routed_to, turn.created_at,
        )


async def handle(user_text: str) -> ConversationOutcome:
    mission = await get_active_mission()
    if mission is None:
        await _archive(user_text, _ONBOARDING_MESSAGE, "conversation")
        return ConversationOutcome(routed_to="conversation", response_text=_ONBOARDING_MESSAGE)

    if _matches_fast_path_greeting(user_text):
        response = await _conversational_reply(user_text, mission)
        await _archive(user_text, response, "conversation")
        return ConversationOutcome(routed_to="conversation", response_text=response)

    if await _needs_reasoning(user_text):
        workflow = await run_request(user_text)
        await _archive(user_text, workflow.decision.summary, "reasoning")
        return ConversationOutcome(routed_to="reasoning", response_text=workflow.decision.summary, workflow=workflow)

    response = await _conversational_reply(user_text, mission)
    await _archive(user_text, response, "conversation")
    return ConversationOutcome(routed_to="conversation", response_text=response)
