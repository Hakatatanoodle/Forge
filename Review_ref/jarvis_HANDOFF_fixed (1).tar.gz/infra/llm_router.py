"""
LLM Router (INF-05/06/07/08; §7 infra/llm_router.py). Every subsystem
calls complete()/complete_json() — nothing talks to a provider SDK
directly (INF-05: "Everything goes through Reason()").

Routing is fixed/hardcoded per architect decision (2026-08-04): Groq for
fast conversational tasks, Gemini for complex reasoning, OpenRouter as
universal fallback. This is NOT the adaptive, learned routing §5.3
defers (INF-V1) — just fixed rules, as §5.1 always intended.

Requires local verification: no provider is reachable from the build
sandbox's network allowlist. Logic (routing, retry, fallback, JSON
parsing) is tested against mocked HTTP calls in tests/test_llm_router.py;
real-provider correctness has not been verified. See ARCHITECTURE_ISSUES.md.
"""
from __future__ import annotations

import asyncio
import json
import os
from typing import Any, Optional

import httpx

from infra.logging import get_logger

log = get_logger("infra.llm_router")

_TIMEOUT = httpx.Timeout(15.0)
_MAX_PRIMARY_ATTEMPTS = 2
_RETRY_DELAY_SECONDS = 1.0

# Fixed routing table (§5.1 — hardcoded, not adaptive).
# Changed 2026-08-11: OpenRouter promoted to primary for every task type.
# Across this entire dogfooding session it succeeded on 100% of attempts
# reached — every Groq/Gemini failure (DNS errors, key-format migrations,
# endpoint changes, model deprecations) cost real debugging time for a
# call that only ever polishes prose or does cheap classification, never
# core logic. Groq demoted to fallback rather than removed.
_TASK_PROVIDER = {
    "fast": "openrouter",
    "conversation": "openrouter",
    "complex": "openrouter",
}
_DEFAULT_PROVIDER = "openrouter"
_FALLBACK_PROVIDER = "groq"


class LLMUnavailableError(Exception):
    pass


class ProviderNotConfiguredError(LLMUnavailableError):
    """Raised when a provider's API key isn't set — retrying won't help,
    so the retry loop skips straight past this provider instead of
    sleeping between attempts that can never succeed."""
    pass


async def _call_groq(system: str, prompt: str, max_tokens: int, task_type: str = "conversation") -> str:
    key = os.environ.get("GROQ_API_KEY")
    if not key:
        raise ProviderNotConfiguredError("GROQ_API_KEY not set")
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}"},
            json={
                "model": "llama-3.1-8b-instant",
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
            },
        )
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            # Improvement (2026-08-11): the default httpx error drops the
            # response body, so a 404 just said "404 Not Found" with no
            # hint why — took real research to trace an OpenRouter 404
            # back to an account-level privacy-setting requirement for
            # free models. Include the body so the real cause (rate
            # limits, data-policy blocks, model deprecation, etc.) is
            # visible directly in the log next time, not rediscovered.
            raise httpx.HTTPStatusError(f"{e} — {resp.text[:300]}", request=e.request, response=e.response) from None
        content = resp.json()["choices"][0]["message"]["content"]
        if not content:
            # Fix (§6.5, 2026-08-11): a soft failure — HTTP 200 but null/empty
            # content — must not propagate as a real string; treat it as a
            # provider failure so complete()'s retry/fallback chain gets a
            # chance to recover, instead of crashing two layers away in
            # complete_json()'s unconditional .strip().
            raise LLMUnavailableError("groq returned empty/null content")
        return content


async def _call_gemini(system: str, prompt: str, max_tokens: int, task_type: str = "conversation") -> str:
    # BUG-fix history (kept for future maintainers — this endpoint has
    # moved fast in 2026, expect to revisit again):
    #   2026-08-05: gemini-1.5-flash fully retired -> switched to
    #     gemini-2.5-flash on the legacy generateContent endpoint.
    #   2026-08-06 #1: still 404'd. Root cause: Google migrated keys to a
    #     new "AQ." format that isn't accepted via `?key=` query param —
    #     needs the `x-goog-api-key` header. Switched to the header.
    #   2026-08-06 #2: STILL 404'd even with the header fix. Root cause
    #     this time: gemini-2.5-flash is now itself deprecated
    #     (alongside gemini-2.0-*/1.5-*), and Google's GA-recommended
    #     endpoint since June 2026 is the new Interactions API
    #     (/v1beta/interactions), not legacy generateContent — different
    #     URL, different request/response shape. Migrated to that,
    #     targeting gemini-3.5-flash (current, non-deprecated).
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        raise ProviderNotConfiguredError("GEMINI_API_KEY not set")
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.post(
            "https://generativelanguage.googleapis.com/v1beta/interactions",
            headers={"x-goog-api-key": key, "Content-Type": "application/json"},
            json={
                "model": "gemini-3.5-flash",
                "input": f"{system}\n\n{prompt}",
                "generation_config": {"max_output_tokens": max_tokens},
            },
        )
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            # Improvement (2026-08-11): the default httpx error drops the
            # response body, so a 404 just said "404 Not Found" with no
            # hint why — took real research to trace an OpenRouter 404
            # back to an account-level privacy-setting requirement for
            # free models. Include the body so the real cause (rate
            # limits, data-policy blocks, model deprecation, etc.) is
            # visible directly in the log next time, not rediscovered.
            raise httpx.HTTPStatusError(f"{e} — {resp.text[:300]}", request=e.request, response=e.response) from None
        data = resp.json()
        # Response shape: {"id": ..., "steps": [{"type": "model_output",
        # "content": [{"type": "text", "text": "..."}]}]}
        texts = [
            part["text"]
            for step in data.get("steps", [])
            if step.get("type") == "model_output"
            for part in step.get("content", [])
            if part.get("type") == "text"
        ]
        return "".join(texts)


async def _call_openrouter(system: str, prompt: str, max_tokens: int, task_type: str = "conversation") -> str:
    # Changed 2026-08-11 (second time same day): the hardcoded
    # meta-llama/llama-3.3-70b-instruct:free slug got pulled from the
    # free tier within hours of being verified live — confirmed via
    # OpenRouter's own error body: "This model is unavailable for free."
    # Hardcoding any specific free-tier slug is inherently fragile; the
    # catalog rotates on a timescale of hours to days, not weeks.
    #
    # Fix: openrouter/free — OpenRouter's own official router alias
    # (launched Feb 2026, per their docs), not a specific model. It
    # auto-selects from whatever free models are live *at request time*
    # and filters for the features the request needs. This is the
    # structurally correct fix for this exact failure mode — "your code
    # keeps working even after individual free models rotate out," per
    # OpenRouter's own documentation — not another guessed slug.
    key = os.environ.get("OPENROUTER_API_KEY")
    if not key:
        raise ProviderNotConfiguredError("OPENROUTER_API_KEY not set")
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}"},
            json={
                "model": "openrouter/free",
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
            },
        )
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            # Improvement (2026-08-11): the default httpx error drops the
            # response body, so a 404 just said "404 Not Found" with no
            # hint why — took real research to trace an OpenRouter 404
            # back to an account-level privacy-setting requirement for
            # free models. Include the body so the real cause (rate
            # limits, data-policy blocks, model deprecation, etc.) is
            # visible directly in the log next time, not rediscovered.
            raise httpx.HTTPStatusError(f"{e} — {resp.text[:300]}", request=e.request, response=e.response) from None
        content = resp.json()["choices"][0]["message"]["content"]
        if not content:
            # Fix (§6.5, 2026-08-11): see matching comment in _call_groq.
            # openrouter/free's multi-backend routing is what actually
            # exposed this — some backend models return null content on
            # a soft failure without the HTTP call itself failing.
            raise LLMUnavailableError("openrouter returned empty/null content")
        return content


def _provider_funcs() -> dict:
    # Built fresh per call, not at module load — resolves the current
    # module-global names, so test mocks (patch("infra.llm_router._call_groq", ...))
    # actually take effect. A dict built once at import time would freeze
    # references to the original functions and silently ignore patches.
    return {"groq": _call_groq, "gemini": _call_gemini, "openrouter": _call_openrouter}


async def complete(prompt: str, system: str = "", task_type: str = "conversation", max_tokens: int = 500) -> str:
    """Retries the primary provider up to _MAX_PRIMARY_ATTEMPTS times, then
    falls back to Groq once, then raises. Callers decide what to do
    on failure (V0's three replaced placeholders fall back to their old
    deterministic templates — see reasoning/orchestrator/insight)."""
    primary = _TASK_PROVIDER.get(task_type, _DEFAULT_PROVIDER)
    last_error: Optional[Exception] = None

    for attempt in range(_MAX_PRIMARY_ATTEMPTS):
        try:
            return await _provider_funcs()[primary](system, prompt, max_tokens, task_type)
        except ProviderNotConfiguredError as e:
            last_error = e
            log.info(f"{primary} not configured — skipping retries, going to fallback")
            break  # no key set; retrying changes nothing
        except Exception as e:  # noqa: BLE001 — transient provider failures are expected, not bugs
            last_error = e
            log.info(f"{primary} attempt {attempt + 1}/{_MAX_PRIMARY_ATTEMPTS} failed: {e}")
            if attempt < _MAX_PRIMARY_ATTEMPTS - 1:
                await asyncio.sleep(_RETRY_DELAY_SECONDS)

    if primary != _FALLBACK_PROVIDER:
        try:
            log.info(f"Falling back to {_FALLBACK_PROVIDER}")
            return await _provider_funcs()[_FALLBACK_PROVIDER](system, prompt, max_tokens, task_type)
        except Exception as e:  # noqa: BLE001
            last_error = e

    raise LLMUnavailableError(f"All providers failed for task_type={task_type}: {last_error}")


async def complete_json(system: str, prompt: str, task_type: str = "conversation", max_tokens: int = 500) -> Optional[dict[str, Any]]:
    """Same as complete(), but parses a JSON object out of the response
    and returns None (never raises) on any failure — the caller's signal
    to use its deterministic fallback."""
    try:
        text = await complete(prompt=prompt, system=system, task_type=task_type, max_tokens=max_tokens)
    except LLMUnavailableError as e:
        log.info(f"complete_json: no provider available ({e}); caller should fall back")
        return None

    if not text:
        # Defense-in-depth: _call_groq/_call_openrouter now raise
        # LLMUnavailableError on empty/null content themselves (§6.5), so
        # this shouldn't be reachable — kept as a second guard rather than
        # trusting every current and future provider function to always
        # validate correctly.
        log.info("complete_json: provider returned empty text; caller should fall back")
        return None

    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Found in dogfooding, 2026-08-07: Gemini sometimes wraps the JSON in
    # extra prose/bullets rather than a clean ```json fence at the very
    # start, so the strip above misses it. Try extracting the outermost
    # {...} object from anywhere in the text before giving up — still
    # falls back to None (caller's deterministic template) on any
    # further failure, same as before.
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            pass

    log.info(f"complete_json: response was not valid JSON: {text[:200]!r}")
    return None
